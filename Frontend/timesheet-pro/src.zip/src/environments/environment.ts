export const environment = {
  production: false,
  apiUrl: 'http://localhost:5117/api',
  hubUrl: 'http://localhost:5117/notificationHub'
};
